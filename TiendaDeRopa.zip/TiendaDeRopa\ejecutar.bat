@echo off
title TiendaDeRopa - Sistema de Gestion y Ventas
chcp 65001 > nul
cd /d "%~dp0"

where java >nul 2>&1
if errorlevel 1 (
  echo.
  echo No se encontro Java. Instale el JDK 17 o superior desde https://adoptium.net
  echo.
  pause
  exit /b 1
)

if not exist "target\TiendaDeRopa.jar" (
  echo.
  echo No se encontro target\TiendaDeRopa.jar
  echo Genere el ejecutable con: mvnw.cmd package
  echo.
  pause
  exit /b 1
)

echo =====================================================
echo   TiendaDeRopa - Sistema de Gestion y Ventas
echo   Iniciando en http://localhost:8080
echo   Para detenerlo: Ctrl + C o cerrar esta ventana
echo =====================================================
start "" /b cmd /c "timeout /t 6 > nul & start http://localhost:8080"
java -jar "target\TiendaDeRopa.jar"
echo.
echo El servidor se detuvo.
pause
