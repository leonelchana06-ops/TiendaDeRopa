# TiendaDeRopa — Sistema de Gestión y Ventas para una Tienda de Ropa

Programación Orientada a Objetos · Sede La Quiaca · 3° Superior · 2026
Integrantes: Esteban Villca Reinaldo · Josias Vargas Uriel · Leonel Chana Fernando
Docente: Ing. Tomás Ramos

Aplicación web en **Java + Spring Boot** (backend) con interfaz en **HTML + CSS + JavaScript** (frontend)
y base de datos relacional **MySQL**. Las tablas las genera **Hibernate automáticamente**: no hay que
ejecutar ningún script SQL, alcanza con tener creada la base de datos.

---

## 1. Cómo ejecutarlo

**Requisitos:** JDK 17 o superior (`javac -version`) y MySQL en ejecución
(XAMPP, WAMP o MySQL Server). El proyecto ya incluye el *Maven Wrapper*, así que no hace falta
instalar Maven.

1. Configure la conexión en `src/main/resources/application.properties`:

   ```properties
   spring.datasource.url=jdbc:mysql://localhost:3306/bd_tienda_ropa?createDatabaseIfNotExist=true
   spring.datasource.username=Leonel
   spring.datasource.password=1234
   ```

   `createDatabaseIfNotExist=true` hace que la base `bd_tienda_ropa` se cree sola. Si prefiere
   crearla a mano, hágalo desde phpMyAdmin o MySQL Workbench y quite ese parámetro.

   > El usuario de MySQL `Leonel` (clave `1234`) ya está creado en esta computadora. En otra PC
   > hay que crearlo una vez desde MySQL Workbench, phpMyAdmin o la consola:
   > ```sql
   > CREATE USER IF NOT EXISTS 'Leonel'@'localhost' IDENTIFIED BY '1234';
   > GRANT ALL PRIVILEGES ON bd_tienda_ropa.* TO 'Leonel'@'localhost';
   > GRANT CREATE ON *.* TO 'Leonel'@'localhost';
   > FLUSH PRIVILEGES;
   > ```

2. Ejecute el proyecto:

   | Forma | Cómo |
   |---|---|
   | **Windows (más fácil)** | Doble clic en `ejecutar.bat` |
   | **Windows (consola)** | `mvnw.cmd spring-boot:run` |
   | **Linux / Mac** | `./mvnw spring-boot:run` |
   | **NetBeans** | Abrir el proyecto y pulsar *Run* (F6) |
   | **Con Maven instalado** | `mvn spring-boot:run` |
   | **Con el .jar ya compilado** | `java -jar target/TiendaDeRopa.jar` |

3. Abra en el navegador **http://localhost:8080**

La primera vez se crean las tablas y se cargan productos, clientes y empleados de ejemplo.
Para empezar con la base vacía, borre las tablas y ponga `datos.ejemplo=false` en
`application.properties`.

> Para generar el `.jar` ejecutable: `mvnw.cmd package` y luego `java -jar target/TiendaDeRopa.jar`.

> En la carpeta también está **Manual-de-uso.pdf**, con las instrucciones completas y capturas de cada pantalla.

---

## 2. Estructura del proyecto

```
TiendaDeRopa/
├── ejecutar.bat                    ← Doble clic para iniciar el sistema (Windows)
├── Manual-de-uso.pdf               ← Manual de instalación y uso en PDF
├── mvnw / mvnw.cmd                 ← Maven Wrapper (no es necesario instalar Maven)
├── pom.xml                         ← Dependencias (Spring Boot, JPA, MySQL)
├── README.md
└── src/main/
    ├── java/ar/edu/laquiaca/tienda/
    │   ├── TiendaApplication.java  ← Punto de entrada (@SpringBootApplication)
    │   ├── controlador/            ← Rutas de la API REST
    │   │   ├── ProductoControlador.java
    │   │   ├── PersonaControlador.java    (clientes y empleados)
    │   │   ├── VentaControlador.java
    │   │   └── ManejadorErrores.java      (respuestas de error en JSON)
    │   ├── modelo/dominio/         ← CLASES POO / entidades JPA
    │   │   ├── Persona.java        (abstracta: base de Cliente y Empleado)
    │   │   ├── Producto.java
    │   │   ├── Cliente.java
    │   │   ├── Empleado.java
    │   │   ├── Venta.java
    │   │   ├── DetalleVenta.java
    │   │   ├── ItemVenta.java      (renglón que se recibe del navegador)
    │   │   ├── Validador.java      (reglas de validación)
    │   │   ├── ErrorValidacion.java
    │   │   └── NoEncontrado.java
    │   ├── repositorio/            ← Acceso a datos con Spring Data JPA
    │   │   ├── ProductoRepositorio.java
    │   │   ├── ClienteRepositorio.java
    │   │   ├── EmpleadoRepositorio.java
    │   │   ├── VentaRepositorio.java
    │   │   └── DetalleVentaRepositorio.java
    │   ├── servicio/               ← Reglas de negocio y transacciones
    │   │   ├── TiendaServicio.java
    │   │   └── TiendaServicioImpl.java
    │   └── config/
    │       └── DatosIniciales.java (carga los datos de ejemplo)
    └── resources/
        ├── application.properties  ← Conexión a MySQL y configuración de JPA
        └── static/                 ← INTERFAZ WEB (se sirve tal cual)
            ├── index.html          (panel principal)
            ├── productos.html      (ABM + stock)
            ├── clientes.html
            ├── empleados.html
            ├── venta.html          (registrar venta)
            ├── ventas.html         (historial y detalle)
            ├── css/estilos.css
            ├── js/comun.js
            └── img/icono.svg
```

Arquitectura en capas: **Vista** (HTML/JS) → **Controlador** (rutas REST) → **Servicio**
(reglas de negocio y transacciones) → **Repositorio** (JPA) → **Base de datos**.

---

## 3. Base de datos (se genera automáticamente)

`spring.jpa.hibernate.ddl-auto=update` hace que Hibernate cree las tablas la primera vez y las
mantenga actualizadas cuando cambian las entidades. **No hay archivos `.sql`** en el proyecto.

| Tabla (generada) | Entidad | Campos principales | Claves |
|---|---|---|---|
| `productos` | `Producto` | `id_producto`, `nombre`, `descripcion`, `precio`, `stock` | PK `id_producto` (auto-incremental) |
| `clientes` | `Cliente` | `id_cliente`, `nombre`, `apellido`, `telefono`, `correo` | PK `id_cliente` |
| `empleados` | `Empleado` | `id_empleado`, `nombre`, `apellido`, `cargo` | PK `id_empleado` |
| `ventas` | `Venta` | `id_venta`, `fecha_hora`, `total`, `id_cliente`, `id_empleado` | PK `id_venta` · FK → `clientes`, `empleados` |
| `detalles_venta` | `DetalleVenta` | `id_detalle`, `id_venta`, `id_producto`, `cantidad`, `subtotal` | PK `id_detalle` · FK → `ventas`, `productos` |

Las claves foráneas que genera Hibernate impiden borrar (con `RESTRICT`) un producto, cliente o
empleado que ya figura en ventas. Los renglones de una venta se eliminan con su venta (`CASCADE`).

Si alguna vez cambia la estructura de una entidad y desea recrear las tablas desde cero, use
`spring.jpa.hibernate.ddl-auto=create` (borra los datos al iniciar) durante ese arranque y luego
vuelva a `update`.

---

## 4. Clases y métodos (secciones 8 a 10 del documento)

Los atributos siguen la convención de Java (camelCase): `id_producto` → `idProducto`, etc.

| Clase | Atributos | Métodos |
|---|---|---|
| **Producto** | idProducto, nombre, descripcion, precio, stock | `modificarDatos(...)`, `actualizarStock(cantidad)` en la entidad; `registrarProducto()`, `modificarProducto()`, `listarProductos()`, `buscarProductoPorId()`, `actualizarStockProducto()`, `eliminarProducto()` en el servicio |
| **Persona** *(abstracta)* | nombre, apellido | `validar()` *(abstracto)*, `getNombreCompleto()` |
| **Cliente** extends Persona | idCliente, telefono, correo | `validar()`, `modificarDatos(...)`; el servicio agrega `registrarCliente()`, `consultarCompras()`, `eliminarCliente()` |
| **Empleado** extends Persona | idEmpleado, cargo | `validar()`, `modificarDatos(...)`; el servicio agrega `registrarEmpleado()`, `consultarVentas()`, `eliminarEmpleado()` |
| **Venta** | idVenta, fechaHora (LocalDateTime), total, cliente, empleado, detalles (List&lt;DetalleVenta&gt;) | `agregarProducto(p, cant)`, `calcularTotal()`, `validar()`, `getUnidades()`; el servicio agrega `registrarVenta()`, `listarVentas()`, `buscarVentaPorId()` |
| **DetalleVenta** | idDetalle, producto, cantidad, subtotal | `calcularSubtotal()`, `getPrecioUnitario()` |

Conceptos de POO aplicados: **encapsulamiento** (atributos privados; el stock solo cambia con
`actualizarStock()`, no hay setters públicos), **herencia** (`Persona` se declara `@MappedSuperclass`
y `Cliente`/`Empleado` heredan sus columnas), **polimorfismo** (`validar()` distinto en cada
subclase), **abstracción** (`Persona` abstracta), **asociación** (Venta–Cliente, Venta–Empleado)
y **composición** (Venta–DetalleVenta, con `cascade = ALL` y `orphanRemoval`).

---

## 5. Registro de una venta y consistencia transaccional

`TiendaServicioImpl.registrarVenta(...)` ejecuta todo en **una sola transacción** (`@Transactional`):

1. Bloquea cada producto con `SELECT ... FOR UPDATE` (bloqueo pesimista de JPA), en orden de
   código de producto para evitar bloqueos cruzados.
2. Comprueba que haya stock suficiente; si no, lanza un error y **no se modifica nada**.
3. Descuenta el stock con `Producto.actualizarStock(-cantidad)`.
4. Guarda la cabecera de la venta y sus renglones (cascada).

Si cualquier paso falla se hace *rollback* y la base queda igual que antes. Además, el servidor
**nunca usa precios enviados por el navegador**: los toma de la base de datos al armar cada renglón.

---

## 6. Validaciones (requerimiento no funcional)

Se validan en el navegador (campos obligatorios, números, correo) **y** en las clases Java
(`Validador`, fuente de verdad): nombre/apellido/cargo obligatorios y con longitud máxima;
precio > 0; stock entero ≥ 0; correo y teléfono con formato válido; venta con cliente, empleado y
al menos un producto; cantidad entera > 0 y no mayor al stock. Los mensajes de error se muestran en
pantalla en español.

---

## 7. API REST (para pruebas o futuras ampliaciones)

| Método | Ruta | Acción |
|---|---|---|
| GET | `/api/productos?buscar=&disponibles=true` | Consultar productos |
| GET | `/api/productos/{id}` | Detalle de un producto |
| POST / PUT / DELETE | `/api/productos[/{id}]` | Registrar / modificar / eliminar |
| POST | `/api/productos/{id}/stock` | Ajustar stock `{"cantidad": 5}` o `-2` |
| GET / POST / PUT / DELETE | `/api/clientes[/{id}]` | Clientes (`/compras` para su historial) |
| GET / POST / PUT / DELETE | `/api/empleados[/{id}]` | Empleados (`/ventas` para su historial) |
| POST | `/api/ventas` | `{"idCliente":1,"idEmpleado":1,"items":[{"idProducto":2,"cantidad":3}]}` |
| GET | `/api/ventas?desde=&hasta=&idCliente=&idEmpleado=` | Historial con filtros |
| GET | `/api/ventas/{id}` | Detalle completo |
| GET | `/api/resumen` | Indicadores del panel |

Los errores se devuelven como `{"error": "mensaje"}` con el código HTTP correspondiente (400, 404 o 500).

---

## 8. Datos de ejemplo

Si las tablas están vacías y `datos.ejemplo=true`, al iniciar se cargan:

* **Productos:** Remera básica, Jean recto, Campera de abrigo, Gorro de lana y Buzo canguro.
* **Clientes:** Consumidor Final, María Quispe y Jorge Mamani.
* **Empleados:** Lucía Cruz (Vendedora) y Carlos Flores (Encargado).
